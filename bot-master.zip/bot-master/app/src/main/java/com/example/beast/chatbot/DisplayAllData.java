package com.example.beast.chatbot;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DisplayAllData extends RecyclerView.Adapter<DisplayAllData.ItemViewHolder> {
    private List<ChatMessage> mUserLsit = new ArrayList<>();
    private Context mContext;

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.msglist, parent, false);
        return new ItemViewHolder(view);
    }

    public DisplayAllData(Context mContext, List<ChatMessage> mUserLsit) {
        this.mContext = mContext;
        this.mUserLsit = mUserLsit;
    }

    @Override
    public void onBindViewHolder(ItemViewHolder viewHolder, int position) {
        ChatMessage model = mUserLsit.get(position);
        if (model.getMsgUser().equals("user")) {


            viewHolder.rightText.setText(model.getMsgText());

            viewHolder.rightText.setVisibility(View.VISIBLE);
            viewHolder.leftText.setVisibility(View.GONE);
        } else {
            viewHolder.leftText.setText(model.getMsgText());

            viewHolder.rightText.setVisibility(View.GONE);
            viewHolder.leftText.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return mUserLsit.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView leftText, rightText;

        public ItemViewHolder(View itemView) {
            super(itemView);
            leftText = (TextView) itemView.findViewById(R.id.leftText);
            rightText = (TextView) itemView.findViewById(R.id.rightText);

        }
    }
}