package com.example.beast.chatbot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignActvity extends AppCompatActivity {
    private EditText edtTxt_mobile_signup;
    private EditText edtTxt_email_signup;
    private EditText edtTxt_name_signup;
    private EditText edtTxt_adhar_no;
    private EditText edtTxt_pass_signup;
    private Button btn_signup;
    private TextView txt_already_account_signup;
    private CheckBox checkbox;
    DatabaseReference ref;
    private DatabaseReference mDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_actvity);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        edtTxt_mobile_signup = findViewById(R.id.edtTxt_mobile_signup);
        edtTxt_email_signup = findViewById(R.id.edtTxt_email_signup);
        edtTxt_name_signup = findViewById(R.id.edtTxt_name_signup);
        edtTxt_adhar_no = findViewById(R.id.edtTxt_adhar_no);
        edtTxt_pass_signup = findViewById(R.id.edtTxt_pass_signup);
        btn_signup = findViewById(R.id.btn_signup);
        txt_already_account_signup = findViewById(R.id.txt_already_account_signup);
        checkbox = findViewById(R.id.checkbox);
        checkbox.setVisibility(View.GONE);

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateEditText(edtTxt_mobile_signup, true) && validateEditText(edtTxt_email_signup) && validateEditText(edtTxt_name_signup) && validateEditText(edtTxt_adhar_no) && validateEditText(edtTxt_pass_signup)) {
                    writeNewUser("",edtTxt_name_signup.getText().toString(),edtTxt_email_signup.getText().toString(),edtTxt_adhar_no.getText().toString(),edtTxt_pass_signup.getText().toString(),edtTxt_mobile_signup.getText().toString());
                } else {
                    Toast.makeText(SignActvity.this, "All fields are required", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private boolean validateEditText(EditText et) {
        if (et.getText().toString().trim().equalsIgnoreCase("") || et.getText().toString() == null) {
            return false;
        } else {
            return true;
        }
    }

    private boolean validateEditText(EditText et, boolean b) {
        if (et.getText().toString().trim().length() == 10) {
            return true;
        } else {
            et.setError("mobile number invalid");
            et.requestFocus();
            return false;
        }
    }

    private void writeNewUser(String userId, String name, String email, String adhar, String password, String mobile) {

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("users");
        String user_Id = mDatabase.push().getKey();
        User user = new User(name, email, adhar, mobile, password);
        mDatabase.child(user_Id).setValue(user);
        Toast.makeText(this, "Successfully Registered", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this,LoginActivity.class));
        finish();
        //mDatabase.child("users").setValue(user);
    }
}
