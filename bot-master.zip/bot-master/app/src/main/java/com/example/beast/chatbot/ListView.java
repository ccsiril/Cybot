package com.example.beast.chatbot;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListView extends RecyclerView.Adapter<ListView.ItemViewHolder> {
    private List<ChatMessage> mUserLsit = new ArrayList<>();
    private Context mContext;
    String date;

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.firstlist, parent, false);
        return new ItemViewHolder(view);
    }

    public ListView(Context mContext, String date) {
        this.mContext = mContext;
        this.date=date;
        Log.e("dddddddddddddd","ddddddddddd"+date);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder viewHolder, int position) {
        Log.e("dddddddddddddd","ddddddddddd"+date);
        viewHolder.date.setText("Date : "+date);
        viewHolder.sts.setText("Current status : Pending");
        viewHolder.ly_root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.startActivity(new Intent(mContext,DetailedActivity.class));
            }
        });
    }

    @Override
    public int getItemCount() {
        return 1;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView date, sts;
        LinearLayout ly_root;
        public ItemViewHolder(View itemView) {
            super(itemView);
            date = (TextView) itemView.findViewById(R.id.txt_date);
            sts = (TextView) itemView.findViewById(R.id.txt_sts);
            ly_root=itemView.findViewById(R.id.ly_root);
        }
    }
}