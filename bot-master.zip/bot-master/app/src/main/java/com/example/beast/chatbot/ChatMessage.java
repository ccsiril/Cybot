package com.example.beast.chatbot;


/**
 * Created by beast on 14/4/17.
 */

public class ChatMessage {

    private String msgText;
    private String msgUser;
    private String msgUserName;
    private String date;



    public ChatMessage(String msgText, String msgUser,String msgUserName,String date){
        this.msgText = msgText;
        this.msgUser = msgUser;
        this.msgUserName=msgUserName;
        this.date=date;


    }


    public String getMsgUserName() {
        return msgUserName;
    }

    public ChatMessage(){

    }

    public String getDate() {
        return date;
    }

    public String getMsgText() {
        return msgText;
    }

    public void setMsgText(String msgText) {
        this.msgText = msgText;
    }

    public String getMsgUser() {
        return msgUser;
    }

    public void setMsgUser(String msgUser) {
        this.msgUser = msgUser;
    }
}
