package com.example.beast.chatbot;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.app.LoaderManager.LoaderCallbacks;

import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.READ_CONTACTS;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {
    EditText edt_password;
    EditText edit_adhar;
    Button btn_login;
    TextView txt_signup;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    private DatabaseReference mDatabase;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        setContentView(R.layout.activity_login);
        edit_adhar = findViewById(R.id.edtTxt_adhar);
        edt_password = findViewById(R.id.edtTxt_password);
        btn_login = findViewById(R.id.btn_login);
        txt_signup = findViewById(R.id.txt_dont_have_account);

        this.preferences = this.getSharedPreferences("myg_prefs", Context.MODE_PRIVATE);
        editor = preferences.edit();



        txt_signup.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, SignActvity.class));
                finish();
            }
        });

        btn_login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                callLogin();
            }
        });


    }


    private void callLogin() {
        Query query = mDatabase.child("users");

    //    Query query = mDatabase.child("users").orderByChild("adhar").equalTo(edit_adhar.getText().toString().trim());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // dataSnapshot is the "issue" node with all children with id 0

                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        // do something with the individual "issues"
                        User usersBean = user.getValue(User.class);
                        Log.e("data","password"+usersBean.password);
                        Log.e("data","email"+usersBean.email);
                        Log.e("data","username"+usersBean.username);
                        Log.e("data","mobile"+usersBean.mobile);

                        if (usersBean.password.equals(edt_password.getText().toString().trim())&&usersBean.adhar.equals(edit_adhar.getText().toString().trim())) {
                            editor.putString("email", usersBean.email);
                            editor.putString("username",usersBean.username);
                            editor.putString("mobile",usersBean.mobile);
                            editor.putString("passwoed",usersBean.password);

                            editor.commit();
                           Intent intent = new Intent(LoginActivity.this, HomeScreen.class);
                           startActivity(intent);
                           finish();
                        } else {
                            //Toast.makeText(LoginActivity.this, "Password is wrong", Toast.LENGTH_LONG).show();
                        }
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "User not found", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}

