package com.example.beast.chatbot;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class HomeScreen extends AppCompatActivity {

    RecyclerView rv_claim;
    FloatingActionButton btn_add;
    DatabaseReference ref;
    SharedPreferences preferences;
    int claimFlag = 0;
    SharedPreferences.Editor editor;
    String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ref = FirebaseDatabase.getInstance().getReference();
        ref.keepSynced(true);
        this.preferences = this.getSharedPreferences("myg_prefs", Context.MODE_PRIVATE);
        editor = preferences.edit();

        setContentView(R.layout.activity_home_screen);


        btn_add = findViewById(R.id.add_claim);
        rv_claim = findViewById(R.id.rv_claim);
        rv_claim.setHasFixedSize(true);
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        rv_claim.setLayoutManager(linearLayoutManager);
        Query query = ref.child("chat");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        ChatMessage chat = user.getValue(ChatMessage.class);
                        try {
                            if (chat.getMsgUserName().equals(preferences.getString("username", "0"))) {
                                claimFlag = 1;
                                date=chat.getDate();
                            }

                        } catch (Exception e) {

                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.e("claim", "l" + claimFlag);

                Log.e("date","date"+date);
                if (claimFlag == 1) {
                    rv_claim.setAdapter(new ListView(HomeScreen.this,date));

                }
            }
        }, 3000);


        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Query query = ref.child("chat");
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for (DataSnapshot user : dataSnapshot.getChildren()) {
                                ChatMessage chat = user.getValue(ChatMessage.class);
                                try {
                                    if (chat.getMsgUserName().equals(preferences.getString("username", "0"))&&chat.getMsgText().equals("completed")) {
                                        claimFlag = 1;
                                        date=chat.getDate();
                                    }

                                } catch (Exception e) {

                                }
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Log.e("claim", "l" + claimFlag);

                        if (claimFlag == 1) {
                            Toast.makeText(HomeScreen.this, "You have one pending request", Toast.LENGTH_SHORT).show();
                        } else {
                            Query query = ref.child("chat").orderByChild("msgUserName").equalTo(preferences.getString("username", "0"));
                            query.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    try{
                                        for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                                            appleSnapshot.getRef().removeValue();
                                        }
                                    }
                                    catch (Exception e){

                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                            startActivity(new Intent(HomeScreen.this, MainActivity.class));
                        }
                    }
                }, 3000);

            }
        });
    }
}
