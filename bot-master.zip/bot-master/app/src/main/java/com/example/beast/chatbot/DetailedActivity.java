package com.example.beast.chatbot;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DetailedActivity extends AppCompatActivity {
    String name;
    String date;
    String type;
    String time;
    String platfom;
    String url;
    TextView txt_name,txt_date,txt_time,txt_platform,txt_url,txt_category;
    DatabaseReference ref;
    SharedPreferences preferences;
    int claimFlag = 0;
    SharedPreferences.Editor editor;
    ArrayList<ChatMessage> chatMessages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed);
        ref = FirebaseDatabase.getInstance().getReference();
        ref.keepSynced(true);
        chatMessages = new ArrayList<>();
        txt_name=findViewById(R.id.txt_name);
        txt_date=findViewById(R.id.txt_date);
        txt_category=findViewById(R.id.txt_category);
        txt_time=findViewById(R.id.txt_time);
        txt_platform=findViewById(R.id.txt_platform);
        txt_url=findViewById(R.id.txt_url);
        this.preferences = this.getSharedPreferences("myg_prefs", Context.MODE_PRIVATE);
        editor = preferences.edit();
        Query query = ref.child("chat");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        ChatMessage chat = user.getValue(ChatMessage.class);
                        try {
                            if (chat.getMsgUserName().equals(preferences.getString("username", "0"))) {
                                chatMessages.add(chat);
                            }

                        } catch (Exception e) {

                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < chatMessages.size(); i++) {
                    try {
                        if (chatMessages.get(i).getMsgText().contains("Enter the date of incident?")) {
                            Log.e("date", "ffff" + chatMessages.get(i + 1).getMsgText());
                            date=chatMessages.get(i + 1).getMsgText();
                            txt_date.setText("Date of incident :"+date);
                        }
                        if (chatMessages.get(i).getMsgText().contains("What should i call you?")){
                            Log.e("name", "ffff" + chatMessages.get(i + 1).getMsgText());
                            name=chatMessages.get(i + 1).getMsgText();
                            txt_name.setText("Name  : "+name);
                        }
                        if (chatMessages.get(i).getMsgText().contains("Enter the time of incident?")){
                            Log.e("time", "ffff" + chatMessages.get(i + 1).getMsgText());
                            time=chatMessages.get(i + 1).getMsgText();
                            txt_time.setText("Time : "+time);
                        }
                        if (chatMessages.get(i).getMsgText().contains("where the incident occurred?")){
                            Log.e("platform", "ffff" + chatMessages.get(i + 1).getMsgText());
                            platfom=chatMessages.get(i + 1).getMsgText();
                            txt_platform.setText("Platform : "+platfom);
                        }
                        if (chatMessages.get(i).getMsgText().contains("Enter the URL,you facing the issue?")){
                            Log.e("url", "ffff" + chatMessages.get(i + 1).getMsgText());
                            url=chatMessages.get(i + 1).getMsgText();
                            txt_url.setText("Url :"+url);
                        }
                        txt_category.setText("Category : Cyber Attack");

                    } catch (Exception e) {

                    }
                }
            }
        }, 3000);

    }
}
